<header class="navigation">
    <!-- <div class="top-header py-2">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <div class="top-header-left text-muted">
                        Head Office, No.839, Road No.2617, No. 626, Al Akar Al Gharab, Kingdom of Bahrin
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="top-header-right float-right">
                        <ul class="list-unstyled mb-0">
                            <li class="top-contact">
                                <a href="tel:+97377177842 "> <i class="ion-android-call mr-2"></i><span class="text-color">+973 77 17 78 42</span>
                                </a>
                            </li>
                             <li class="language ml-3">
                                <select class="country" name="country">
                                  <option>EN</option>
                                  <option>FR</option>
                                  <option>JA</option>
                                  <option>CA</option>
                                  <option>FR</option>
                                </select>
                            </li> 
                        </ul>
                    </div>
                </div>
            </div>
    </div> -->
    
        <nav class="navbar navbar-expand-lg bg-white w-100 p-0" id="navbar">
            <div class="container">
              <a class="navbar-brand" href="index.php"><img src="images/logo.png" alt="Eden" class="img-fluid"></a>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
                <span class="fa fa-bars"></span>
              </button>
              <!--Include menu -start -->
              <?php include 'menu.html' ?>
              <!--Include menu -stop -->
            </div>
        </nav>
    </header>
    
