define( function() {
	"use strict";

	return ( /^margin/ );
} );
